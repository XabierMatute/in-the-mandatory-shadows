extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_normal_mode_button_pressed() -> void:
#	Turn test mode off
	get_tree().change_scene_to_file("res://Scenes/Menus/LevelMenu.tscn")


func _on_test_mode_button_pressed() -> void:
#	Turn test mode on
	get_tree().change_scene_to_file("res://Scenes/Menus/LevelMenu.tscn")
