extends Node


func _on_l_1_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Levels/Level1.tscn")



func _on_l_2_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Levels/Level2.tscn")



func _on_l_3_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Levels/Level3.tscn")
